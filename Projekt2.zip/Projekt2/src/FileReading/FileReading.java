package FileReading; /**
 This class is mainly used for reading from input file and converting it all to one String. It gets path of a file as input and then through Java Stream properties it returns String which is content of a file.
 This class also throws Exceptions when file Path is wrong and file does not exists. Class contains constructor setting local variable filePath and method readFromFile which creates String mentioned above.
 * */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class FileReading implements IFileReading {

    private String filePath;

    /***
     * Constructor assigning Path of a file to the local variable filePath
     * @param filePath String which contains Path of a file
     */
    public FileReading(String filePath){
        this.filePath = filePath;
    }

    /**
     * Function which takes filePath of a Bibtex File and then convert all its content to a String
     * When file of a Path is wrong Function throws IOException
     * @return String which contains all Bibtex File content
     */
    public String readFromFile()throws IOException{
        StringBuilder Builder = new StringBuilder();

        try (Stream<String> s = Files.lines(Paths.get(filePath))){
            s.forEach(line -> Builder.append(line).append("\n"));
        /*}
        catch (IOException exception) {
            System.out.println("File not found");
            exception.printStackTrace();

        }*/}

        return Builder.toString();
    }

    public static String readFromURL(String urlString) throws IOException{
        BufferedReader reader = null;
        try {
            URL url = new URL(urlString);
            reader = new BufferedReader(new InputStreamReader(url.openStream()));
            StringBuffer buffer = new StringBuffer();
            int read;
            char[] chars = new char[1024];
            while ((read = reader.read(chars)) != -1)
                buffer.append(chars, 0, read);

            return buffer.toString();
        } finally {
            if (reader != null)
                reader.close();
        }
    }
}