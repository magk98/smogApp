package FileReading;

import java.io.IOException;

/**
 * This Interface can be implemented by a class made for reading from Bibtex file and converting it all to one String. It gets path of a file as input and then through Java Stream properties it returns String which is content of a file.
 */
public interface IFileReading {
    /**
     * Function which takes filePath of a Bibtex File and then convert all its content to a String
     * When file of a Path is wrong Function throws IOException
     * @return String which contains all Bibtex File content
     * @throws IOException when filePath is wrong
     */
    String readFromFile() throws IOException;
}
