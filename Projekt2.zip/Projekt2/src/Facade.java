
import UtilAlgos.Singleton;

import java.io.*;
import java.text.ParseException;
public class Facade {

    public static void main(String[] args) {
        try {
            System.out.println(Singleton.getSingleEntry().commander(args));
        } catch (IOException e) {
            System.out.println(e.getMessage());
            //System.out.println("Wrong file path!");
        }
        catch (IllegalArgumentException i){
            System.out.println("Nieprawidłowa liczba argumentów!");
        }
        catch(ParseException p){
            System.out.println(p.getMessage());
        }
    }
}
