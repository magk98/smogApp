package SmogData;

public class Positions {
    private String id;
    private String stationId;
    private Param param;

    private static class Param{
        private String paramName;
        private String paramFormula;
        private String paramCode;
        private String idParam;

        public Param(String paramName, String paramFormula, String paramCode, String idParam){
            this.setParamName(paramName);
            this.setParamFormula(paramFormula);
            this.setParamCode(paramCode);
            this.setIdParam(idParam);
        }

        public String toString(){
            return "Nazwa Parametru: " + this.getParamName() + "\nWzor chemiczny: " + this.getParamFormula() + "\nKod parametru: " + this.getParamCode() + "\nID parametru: " + this.getIdParam();
        }

        public String getParamName() {
            return paramName;
        }

        public void setParamName(String paramName) {
            this.paramName = paramName;
        }

        public String getParamFormula() {
            return paramFormula;
        }

        public void setParamFormula(String paramFormula) {
            this.paramFormula = paramFormula;
        }

        public String getParamCode() {
            return paramCode;
        }

        public void setParamCode(String paramCode) {
            this.paramCode = paramCode;
        }

        public String getIdParam() {
            return idParam;
        }

        public void setIdParam(String idParam) {
            this.idParam = idParam;
        }
    }


    public Positions(String id, String stationId, Param param){
        this.setId(id);
        this.setStationId(stationId);
        this.setParam(param);
    }

    public String toString(){
        return "\nID: " + this.getId() + "\nID stacji: " + this.getStationId() + "\n" + this.getParam().toString();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStationId() {
        return stationId;
    }

    public void setStationId(String stationId) {
        this.stationId = stationId;
    }

    public Param getParam() {
        return param;
    }

    public void setParam(Param param) {
        this.param = param;
    }
}
