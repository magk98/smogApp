package SmogData;


public class SmogData {
    private String key;
    private Values[] values;

    public static class Values {
        private String date;
        private Double value = -1.0;

        public Values(String date, Double value){
            this.setDate(date);
            this.setValue(value);
        }

        public String toString(){
            return "Data: " + this.getDate() + "\nWartosc: " + this.getValue();
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public Double getValue() {
            if(value == null) return -1.0;
            return value;
        }

        public void setValue(Double value) {
            if(value != null) this.value = value;
            if(value == null) this.value = -1.0;
        }
    }


    public SmogData(String key, Values[] values){
        this.setKey(key);
        this.setValues(values);
    }

    public String toString(){
        String result = this.getKey();
        for(Values v : getValues()){
            result += "\n" + v.toString();
        }
        return result;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Values[] getValues() {
        return values;
    }

    public void setValues(Values[] values) {
        this.values = values;
    }
}
