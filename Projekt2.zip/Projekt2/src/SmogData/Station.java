package SmogData;

public class Station {
    private String id;
    private String stationName;
    private String gegrLat;
    private String gegrLon;
    private City city;
    private String addressStreet;

    private static class City {
        private String id;
        private String name;
        private Commune commune;

        private static class Commune {
            private String communeName;
            private String districtName;
            private String provinceName;

            public Commune(String communeName, String districtName, String provinceName){
                setCommuneName(communeName);
                setDistrictName(districtName);
                setProvinceName(provinceName);
            }

            public String toString(){
                return "Gmina: " + getCommuneName() + "\nPowiat: " + getDistrictName() + "\nWojewodztwo: " + getProvinceName();
            }

            public void setCommuneName(String communeName) {
                this.communeName = communeName;
            }

            public void setDistrictName(String districtName) {
                this.districtName = districtName;
            }

            public void setProvinceName(String provinceName) {
                this.provinceName = provinceName;
            }

            public String getCommuneName() {
                return communeName;
            }

            public String getDistrictName() {
                return districtName;
            }

            public String getProvinceName() {
                return provinceName;
            }
        }


        public City(String id, String name, Commune commune){
            this.setId(id);
            this.setName(name);
            this.setCommune(commune);
        }

        public String toString(){
            return getCommune().toString() + "\nMiasto id: " + this.getId() + "\nMiasto: " + this.getName();
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Commune getCommune() {
            return commune;
        }

        public void setCommune(Commune commune) {
            this.commune = commune;
        }
    }


    public Station(String id, String stationName, String gegrLat, String gegrLon, City city, String addressStreet){
        this.setId(id);
        this.setStationName(stationName);
        this.setGegrLat(gegrLat);
        this.setGegrLon(gegrLon);
        this.setCity(city);
        this.setAddressStreet(addressStreet);
    }

    public String toString(){
        String res= "";
        if(this.getCity() != null) res+=this.getCity();
        return res + "\nNazwa Stacji: " + this.getStationName() + "\nStacja id: " + this.getId() + "\nGegrLat: " + this.getGegrLat() + "\nGegrLon: " + this.getGegrLon() + "\nUlica: " + this.getAddressStreet();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStationName() {
        return stationName;
    }

    public void setStationName(String stationName) {
        this.stationName = stationName;
    }

    public String getGegrLat() {
        return gegrLat;
    }

    public void setGegrLat(String gegrLat) {
        this.gegrLat = gegrLat;
    }

    public String getGegrLon() {
        return gegrLon;
    }

    public void setGegrLon(String gegrLon) {
        this.gegrLon = gegrLon;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public String getAddressStreet() {
        return addressStreet;
    }

    public void setAddressStreet(String addressStreet) {
        this.addressStreet = addressStreet;
    }
}
