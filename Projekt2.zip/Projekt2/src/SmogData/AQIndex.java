package SmogData;

public class AQIndex {
    public String id;
    String CalcDate;
    IndexLevel stIndexLevel;
    String stSourceDataDate;
    String so2CalcDate;
    IndexLevel so2IndexLevel;
    String so2SourceDataDate;
    String no2CalcDate;
    IndexLevel no2IndexLevel;
    String no2SourceDataDate;
    String coCalcDate;
    IndexLevel coIndexLevel;
    String coSourceDataDate;
    String pm10CalcDate;
    IndexLevel pm10IndexLevel;
    String pm10SourceDataDate;
    String pm25CalcDate;
    IndexLevel pm25IndexLevel;
    String pm25SourceDataDate;
    String o3CalcDate;
    IndexLevel o3IndexLevel;
    String o3SourceDataDate;
    String c6h6CalcDate;
    IndexLevel c6h6IndexLevel;
    String c6h6SourceDataDate;

    private static class IndexLevel {
        private String id;
        private String indexLevelName;

        public IndexLevel(String id, String indexLevelName){
            this.setId(id);
            this.setIndexLevelName(indexLevelName);
        }

        public String toString(){
            return "ID: " + this.getId() + "\nPoziom: " + this.getIndexLevelName();
        }

        public String airLevel(){
            return this.getIndexLevelName();
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getIndexLevelName() {
            return indexLevelName;
        }

        public void setIndexLevelName(String indexLevelName) {
            this.indexLevelName = indexLevelName;
        }
    }

    public AQIndex(String id, String CalcDate, IndexLevel stIndexLevel, String stSourceDataDate, String so2CalcDate, IndexLevel so2IndexLevel, String so2SourceDataDate, String no2CalcDate, IndexLevel no2IndexLevel, String no2SourceDataDate, String coCalcDate, IndexLevel coIndexLevel, String coSourceDataDate, String pm10CalcDate, IndexLevel pm10IndexLevel, String pm10SourceDataDate, String pm25CalcDate, IndexLevel pm25IndexLevel, String pm25SourceDataDate, String o3CalcDate, IndexLevel o3IndexLevel, String o3SourceDataDate, String c6h6CalcDate, IndexLevel c6h6IndexLevel, String c6h6SourceDataDate){
        this.id = id;
        this.CalcDate = CalcDate;
        this.stIndexLevel = stIndexLevel;
        this.stSourceDataDate = stSourceDataDate;
        this.so2CalcDate = so2CalcDate;
        this.so2IndexLevel = so2IndexLevel;
        this.so2SourceDataDate = so2SourceDataDate;
        this.no2CalcDate = no2CalcDate;
        this.no2IndexLevel = no2IndexLevel;
        this.no2SourceDataDate = no2SourceDataDate;
        this.coCalcDate = coCalcDate;
        this.coIndexLevel = coIndexLevel;
        this.coSourceDataDate = coSourceDataDate;
        this.pm10CalcDate = pm10CalcDate;
        this.pm10IndexLevel = pm10IndexLevel;
        this.pm10SourceDataDate = pm10SourceDataDate;
        this.pm25CalcDate = pm25CalcDate;
        this.pm25IndexLevel = pm25IndexLevel;
        this.pm25SourceDataDate = pm25SourceDataDate;
        this.o3CalcDate = o3CalcDate;
        this.o3IndexLevel = o3IndexLevel;
        this.o3SourceDataDate = o3SourceDataDate;
        this.c6h6CalcDate = c6h6CalcDate;
        this.c6h6IndexLevel = c6h6IndexLevel;
        this.c6h6SourceDataDate = c6h6SourceDataDate;
    }

    public String toString(){
        return "ID: " + id + "\nDzień, w którym sprawdzano: " + CalcDate + "\nstIndexLevel: " + stIndexLevel.toString() + "\nData:" + stSourceDataDate + "\nPomiar SO2 dnia: " +  so2CalcDate + so2IndexLevel.toString() + "\nJakies tam daty: " + so2SourceDataDate;

    }

    public String AirCondition(){
        return "Stan powietrza: " + this.stIndexLevel.airLevel();
    }

    public String parameterCondition(String parameter){
        return null;
    }

}
