package CacheCreator;

import FileReading.FileReading;
import SmogData.Positions;
import SmogData.Station;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedHashMap;

public interface ICacheCreator {

    /**
     * Function used to create cache with all the stations
     */
    public static void createStationsCache(){
        try{
            String urlContent = FileReading.readFromURL("http://api.gios.gov.pl/pjp-api/rest/station/findAll");
            BufferedWriter writer = new BufferedWriter(new FileWriter("src/temporaryRequests/findAllRequest"));
            writer.write(urlContent);
            writer.close();
        } catch(IOException e){
            System.out.println("Something went wrong while creating Stations Cache!");
        }
    }

    /**
     * Function which creates caches with all sensors belonging to given to station
     * @param stations - map of all stations
     */
    public static void createSensorsCache(LinkedHashMap<String, Station> stations){
        try {
            for(String key : stations.keySet()) {
                String urlContent = FileReading.readFromURL("http://api.gios.gov.pl/pjp-api/rest/station/sensors/" + stations.get(key).getId());
                BufferedWriter writer = new BufferedWriter(new FileWriter("src/temporaryRequests/Sensory/station" + stations.get(key).getId()));
                writer.write(urlContent);
                writer.close();
            }
        } catch(IOException e){
            System.out.println("Something went wrong while creating Sensors Caches!");
        }
    }

    /**
     * Function which creates caches with AQIndex for every Station
     * @param stations - map of stations
     */
    public static void createAQIndexCaches(LinkedHashMap<String, Station> stations){
        try {
            for(String key : stations.keySet()) {
                String urlContent = FileReading.readFromURL("http://api.gios.gov.pl/pjp-api/rest/aqindex/getIndex/" + stations.get(key).getId());
                BufferedWriter writer = new BufferedWriter(new FileWriter("src/temporaryRequests/indeksyPowietrza/IndeksJakosci" + stations.get(key).getId()));
                writer.write(urlContent);
                writer.close();
            }
        } catch(IOException e){
            System.out.println("Something went wrong while creating Air Quality Index Caches!");
        }
    }

    /**
     * Function which creates Measurement Data for every sensor
     * @param positions - map of sensors
     */
    public static void createDataCaches(LinkedHashMap<String, Positions> positions){
        try {
            for(String key : positions.keySet()) {
                String urlContent = FileReading.readFromURL("http://api.gios.gov.pl/pjp-api/rest/data/getData/" + positions.get(key).getId());
                BufferedWriter writer = new BufferedWriter(new FileWriter("src/temporaryRequests/DanePomiarowe/DataCacheForSensor" + positions.get(key).getId()));
                writer.write(urlContent);
                writer.close();
            }
        } catch(IOException e){
            System.out.println("Something went wrong while creating Data Caches!");
        }
    }

}
