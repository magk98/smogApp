package CacheCreator;

import SmogData.Positions;
import SmogData.Station;
import FileReading.FileReading;
import com.google.gson.Gson;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class CacheCreator{

    public static void createCommander(LinkedHashMap<String, Station> stations,  LinkedHashMap<String, Positions> positions, LinkedList<String> stationsID) throws IOException{
        CacheCreator.createStationsCache();
        Gson gson1 = new Gson();
        FileReading helper = new FileReading("src/temporaryRequests/findAllRequest");
        String userJson = helper.readFromFile();
        Station[] userObject = gson1.fromJson(userJson, Station[].class);
        for (int i = 0; i < userObject.length; i++)  {
            stations.put(userObject[i].getStationName(), userObject[i]);
            stationsID.add(userObject[i].getId());
        }
        CacheCreator.createAQIndexCaches(stations);
        CacheCreator.createSensorsCache(stations);
        for(String s : stationsID) {
            Gson gson2 = new Gson();
            FileReading helper2 = new FileReading("src/temporaryRequests/Sensory/station" + s);
            String userJson2 = helper2.readFromFile();
            Positions[] pos = gson2.fromJson(userJson2, Positions[].class);
            for (int i = 0; i < pos.length; i++) {
                positions.put(pos[i].getId(), pos[i]);
            }
            //CacheCreator.createDataCaches(positions);
        }
    }
    /**
     * Function used to create cache with all the stations
     */
    public static void createStationsCache(){
        try{
            BufferedWriter CacheDate = new BufferedWriter(new FileWriter("src/temporaryRequests/measDate"));
            String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
            CacheDate.write(timeStamp);
            CacheDate.close();
            String urlContent = FileReading.readFromURL("http://api.gios.gov.pl/pjp-api/rest/station/findAll");
            BufferedWriter writer = new BufferedWriter(new FileWriter("src/temporaryRequests/findAllRequest"));
            writer.write(urlContent);
            writer.close();
        } catch(IOException e){
            System.out.println("Something went wrong while creating Stations Cache!");
        }
    }

    public static boolean checkCacheExpiration(String CacheDate) {
        try {
            String timeNow = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
            Date timeNowDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.UK).parse(timeNow);
            Date cacheDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.UK).parse(CacheDate);
            long diff = cacheDate.getTime() - timeNowDate.getTime();
            long hours = TimeUnit.MILLISECONDS.toHours(diff);
            return Math.abs(hours) > 5.0;
        }
        catch(ParseException p) {
            System.out.println(p.getMessage());
        }
        return false;
    }

    /**
     * Function which creates caches with all sensors belonging to given to station
     * @param stations - map of all stations
     */
    public static void createSensorsCache(LinkedHashMap<String, Station> stations){
        try {
            for(String key : stations.keySet()) {
                String urlContent = FileReading.readFromURL("http://api.gios.gov.pl/pjp-api/rest/station/sensors/" + stations.get(key).getId());
                BufferedWriter writer = new BufferedWriter(new FileWriter("src/temporaryRequests/Sensory/station" + stations.get(key).getId()));
                writer.write(urlContent);
                writer.close();
            }
        } catch(IOException e){
            System.out.println("Something went wrong while creating Sensors Caches!");
        }
    }

    /**
     * Function which creates caches with AQIndex for every Station
     * @param stations - map of stations
     */
    public static void createAQIndexCaches(LinkedHashMap<String, Station> stations){
        try {
            for(String key : stations.keySet()) {
                String urlContent = FileReading.readFromURL("http://api.gios.gov.pl/pjp-api/rest/aqindex/getIndex/" + stations.get(key).getId());
                BufferedWriter writer = new BufferedWriter(new FileWriter("src/temporaryRequests/indeksyPowietrza/IndeksJakosci" + stations.get(key).getId()));
                writer.write(urlContent);
                writer.close();
            }
        } catch(IOException e){
            System.out.println("Something went wrong while creating Air Quality Index Caches!");
        }
    }

    /**
     * Function which creates Measurement Data for every sensor
     * @param positions - map of sensors
     */
    public static void createDataCaches(LinkedHashMap<String, Positions> positions){
        try {
            for(String key : positions.keySet()) {
                String urlContent = FileReading.readFromURL("http://api.gios.gov.pl/pjp-api/rest/data/getData/" + positions.get(key).getId());
                BufferedWriter writer = new BufferedWriter(new FileWriter("src/temporaryRequests/DanePomiarowe/DataCacheForSensor" + positions.get(key).getId()));
                writer.write(urlContent);
                writer.close();
            }
        } catch(IOException e){
            System.out.println("Something went wrong while creating Data Caches!");
        }
    }

}
