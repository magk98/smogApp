package UtilAlgos;

import CacheCreator.CacheCreator;
import FileReading.FileReading;
import SmogData.Positions;
import SmogData.Station;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;

public class Singleton {

    private static final Singleton singleEntry = new Singleton();

    private Singleton(){}

    public String commander(String[] args) throws IOException, ParseException {
        LinkedHashMap<String, Station> stations = new LinkedHashMap<>();
        LinkedHashMap<String, Positions> positions = new LinkedHashMap<>();
        LinkedList<String> stationsID = new LinkedList<>();
        HashMap<String, Integer> acceptableValues = UtilFunctions.setAcceptableValuesMap();

        if (args.length == 0) {
            /***Displaying help*/
            UtilFunctions help = new UtilFunctions();
            return help.toString() + "\n";
        }
        if (args.length == 1) {
            /*** Refreshing cache*/
            if (args[0].equals("-r")) {
                FileReading helper = new FileReading("src/temporaryRequests/measDate");
                String measDate = helper.readFromFile();
                if(CacheCreator.checkCacheExpiration(measDate)) {
                    CacheCreator.createCommander(stations, positions, stationsID);
                    return "Cache refreshed";
                }
                return "Cache is up to date, no need to refresh.";
            }
        } else  {
            switch (args[0]) {
                case "-1":
                    return (UtilFunctions.AirQuality(args, stations));
                case "-2":
                    return (UtilFunctions.secondFunctionality(args, stations));
                case "-3":
                    if (args.length != 5) throw new IllegalArgumentException();
                    float average = UtilFunctions.averageValue(args, stations, 2, 1);
                    if (average == -1) return ("Nie odnaleziono stacji/parametru/zła data");
                    else
                        return ("Srednia wartosc parametru " + args[2].toUpperCase() + ": " + (average) + " ug/m3");
                case "-4":
                    return (UtilFunctions.fourthFunctionality(args, stations));
                case "-5":
                    return (UtilFunctions.fifthFunctionality(args, stations));
                case "-6":
                    return(UtilFunctions.sixthFunctionality(args, stations, acceptableValues));
                case "-7":
                    return (UtilFunctions.seventhFunctionality(args, stations));
                case "-8":
                    return (UtilFunctions.eighthFunctionality(args, stations));
                default:
                    return ("Zła opcja programu!");

            }
        }
        return "";
    }





    static public Singleton getSingleEntry(){
        return singleEntry;
    }
}
