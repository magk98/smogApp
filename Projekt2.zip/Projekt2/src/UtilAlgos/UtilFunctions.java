package UtilAlgos;

import FileReading.FileReading;
import SmogData.Positions;
import SmogData.SmogData;
import SmogData.Station;
import SmogData.AQIndex;
import com.google.gson.Gson;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class UtilFunctions {

    /**
     * This function was made to help user in proper use of an Smog application.
     * Help will show in which way user can run program and which functionalities does it provides.
     * @return help which show to user how program should be used, with which arguments, with which order etc.
     */
    public String toString(){
        return "\nThis is Smog App which allows you to follow current air condition in your area.\n" +
                "You can use this program in a few possible ways depending on which arguments will you provide:\n" +
                "1. \"-r\" Which refreshes all caches.\n" +
                "2. \"-c\" Which checks and refreshes all caches when it's needed.\n" +
                "3. \"-1 <Station name>\" Which shows you current air condition from given station.\n" +
                "4. \"-2 <Station name> <Parameter name> <Date>\" Which shows you value of given parameter in given time from given station. \n" +
                "5. \"-3 <Station name> <Parameter name> <Period Start> <Period End>\" Which shows you average value of a given parameter between given dates from given station.\n" +
                "6. \"-4 <Station name> <Period start>\" Which shows you which parameter had most difference between max and min values from given start date until now.\n" +
                "7. \"-5 <Date>\" Which shows you which parameter had the lowest value at given time.\n" +
                "8. \"-6 <Station name> <Date> \" Which shows you which parameters have exceeded their acceptable values.\n" +
                "9. \"-7 <Parameter name>\" Which shows you when and where given parameter had the lowest and the highest value. \n" +
                "10. \"-8 <Parameter name> <Station/s> <Period start> <Period End> \" Which displays values of the given parameter and how they changed in the given time period on the given stations as a diagram.\n" +
                "Be careful: \n" +
                "Parameter name should be one from the \"NO2, SO2, PM10, PM25, C6H6, O3, CO\". \n" +
                "Date should be in format \"YYYY-MM-DD HH:MM:SS\" and usually measurements are taken at full hours.\n";
    }

    /**
     * Utility function made to set Hash Map with acceptable values.
     * It is used later in deciding whether current values has exceeded its acceptable value or not
     * @return - Hash Map which contains acceptable values of all air parameters (like SO2, NO2, PM10, PM2.5, SO2, CO, C6H6 O3)
     */
    public static HashMap<String, Integer> setAcceptableValuesMap(){
        HashMap<String, Integer> acceptableValues = new HashMap<>();
        acceptableValues.put("PM10", 50);
        acceptableValues.put("O3", 120);
        acceptableValues.put("NO2", 200);
        acceptableValues.put("PM2.5", 25);
        acceptableValues.put("SO2", 350);
        acceptableValues.put("CO", 10000);
        acceptableValues.put("C6H6", 5);
        return acceptableValues;
    }

    /**
     * Function made to sort Map of all parameter that have exceeded their values.
     * It gets map as an input and then sorts it using red black tree (it inserts exceeded values as keys in this tree).
     * @param exceededParameters - map of all parameters that have exceeded values
     * @return - sorted map of exceeded parameter values
     */
    private static Map<String, Double> sortMap(Map<String, Double> exceededParameters){
        TreeMap<Double, String> reversedTree =  new TreeMap<>();
        LinkedHashMap<String, Double> resultTree = new LinkedHashMap<>();
        for(String key : exceededParameters.keySet()) reversedTree.put(exceededParameters.get(key), key);
        for (Double key : reversedTree.keySet()) resultTree.put(reversedTree.get(key), key);
        return resultTree;
    }


    /**
     * Utility function made to draw diagrams of given values. It also gets converter as an input to set diagram squares properly.
     * @param converter - average of all given values
     * @param value - value of a current parameter from given station at given time
     * @return - part of a diagram with values
     */
    private static String drawDiagram(float converter, double value){
        String result = "";
        converter /= 8;
        while(value > converter){
            result += " []";
            value -= converter;
        }
        return result;
    }

    /**
     * This utility function is made to help in proper displaying average value of one of the parameters (third of the functionalities).
     * It count average value of a given parameter on the given station within specified time period.
     * It is also used to set converter properly in the eighth of the functionalities
     * @param args - Array which contains informations about which parameter do we want to calculate, on which station and within which time period
     * @param stations - HashMap with all stations
     * @return average - return average value of a given parameter within specified time period on specified station
     * @throws IOException - function throws such Exception when a problem with file has occurred. Also it is thrown when number of arguments is inappropriate
     * @throws ParseException - function throws such Exception when a problem with parsing date has occurred.
     */ //third functionality
    public static float averageValue(String[] args, LinkedHashMap<String, Station> stations, int paramIndex, int stationIndex) throws IOException, ParseException {
        FileReading helper = new FileReading("src/temporaryRequests/findAllRequest");
        String userJson = helper.readFromFile();
        Gson gson1 = new Gson();
        Gson gson2 = new Gson();
        Station[] userObject = gson1.fromJson(userJson, Station[].class);
        float average = 0;
        int count = 0;
        for (int i = 0; i < userObject.length; i++)
            stations.put(userObject[i].getStationName(), userObject[i]);
        for (String key : stations.keySet()) {
            if (args[stationIndex].toLowerCase().equals(key.toLowerCase())) {
                FileReading helper2 = new FileReading("src/temporaryRequests/Sensory/station" + stations.get(key).getId());
                String userJson1 = helper2.readFromFile();
                Positions[] sensors = gson2.fromJson(userJson1, Positions[].class);
                for (int i = 0; i < sensors.length; i++) {
                    String userJson2 = FileReading.readFromURL("http://api.gios.gov.pl/pjp-api/rest/data/getData/" + sensors[i].getId());
                    Gson gson3 = new Gson();
                    SmogData smogParam = gson3.fromJson(userJson2, SmogData.class);
                    if (smogParam.getKey().equals(args[paramIndex].toUpperCase())) {
                        Date beginDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).parse(args[args.length-2]);
                        Date endDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).parse(args[args.length-1]);
                        for (SmogData.Values v : smogParam.getValues()) {
                            Date measDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).parse(v.getDate());
                            if(!measDate.before(beginDate) && !measDate.after(endDate) && v.getValue() >= 0) {
                                average += v.getValue();
                                count++;
                            }
                        }
                    }
                }
            }
        }
        if(count==0) average = -1;
        return average/count;
    }

    /**
     * Utility function created to measure current air quality at the given station.
     * It takes station name as an input and returns current air quality to the user.
     * @param args - Argument containing name of a station which from user wants to know how is current air quality
     * @param stations - Map of the stations
     * @return current air quality on the given station or an information that station was not found when station name was incorrect
     * @throws IOException - function throws such Exception when a problem with file has occurred. Also it is thrown when number of arguments is inappropriate
     */ //first functionality
    public static String AirQuality(String[] args, LinkedHashMap<String, Station> stations) throws IOException{
        if(args.length != 2) throw new IllegalArgumentException();
        FileReading helper = new FileReading("src/temporaryRequests/findAllRequest");
        String userJson = helper.readFromFile();
        String result = "";
        Gson gson1 = new Gson();
        Gson gson2 = new Gson();
        Station[] userObject = gson1.fromJson(userJson, Station[].class);
        for (int i = 0; i < userObject.length; i++)
            stations.put(userObject[i].getStationName(), userObject[i]);
        for (String key : stations.keySet()) {
            if (args[1].toLowerCase().equals(key.toLowerCase())) {
                FileReading AQIhelper = new FileReading("src/temporaryRequests/indeksyPowietrza/indeksJakosci" + stations.get(key).getId());
                String userJson1 = AQIhelper.readFromURL("http://api.gios.gov.pl/pjp-api/rest/aqindex/getIndex/" + stations.get(key).getId());
                AQIndex aqIndex = gson2.fromJson(userJson1, AQIndex.class);
                result = stations.get(key).getStationName() + "\n" + aqIndex.AirCondition();
                break;
            }
        }
        if(result == "") return "Nie znaleziono stacji!";
        else return result;
    }

    /**
     * This function was created to show current parameter condition on the given station at specified time.
     * It gets Parameter name, station name and measurement date as an input and returns current parameter condition.
     * @param args - Array containing arguments provided by user such as parameter name, station name and measurement date in this specified order.
     * @param stations - Map of all stations
     * @return - Current parameter condition on given station at given time or information when station was not found or station does not exists
     * @throws IOException - function throws such Exception when a problem with file has occurred. Also it is thrown when number of arguments is inappropriate
     */
    public static String secondFunctionality(String[] args, LinkedHashMap<String, Station> stations) throws IOException{
        if(args.length != 4) throw new IllegalArgumentException();
        FileReading helper = new FileReading("src/temporaryRequests/findAllRequest");
        String userJson = helper.readFromFile();
        Gson gson1 = new Gson();
        Gson gson2 = new Gson();
        String result = "";
        boolean stationFound = false;
        boolean dateFound = false;
        boolean parameterFound = false;
        Station[] userObject = gson1.fromJson(userJson, Station[].class);
        for (int i = 0; i < userObject.length; i++)
            stations.put(userObject[i].getStationName(), userObject[i]);
        for (String key : stations.keySet()) {
            if (args[1].toLowerCase().equals(key.toLowerCase())) {
                stationFound = true;
                FileReading helper2 = new FileReading("src/temporaryRequests/Sensory/station" + stations.get(key).getId());
                String userJson1 = helper2.readFromFile();
                Positions[] sensors = gson2.fromJson(userJson1, Positions[].class);
                for (int i = 0; i < sensors.length; i++) {
                    String userJson2 = FileReading.readFromURL("http://api.gios.gov.pl/pjp-api/rest/data/getData/" + sensors[i].getId());
                    Gson gson3 = new Gson();
                    SmogData smogParam = gson3.fromJson(userJson2, SmogData.class);
                    if (smogParam.getKey().equals(args[2].toUpperCase())) {
                        for (SmogData.Values v : smogParam.getValues()) {
                            if (v.getDate().equals(args[3])) {
                                if(v.getValue() >=0 ) {
                                    result = "Wartość " + smogParam.getKey() + ": " + v.getValue() + " ug/m3";
                                    dateFound = true;
                                    parameterFound = true;
                                    break;
                                }
                            }
                            parameterFound = true;
                        }
                    }
                }
            }
        }
        if(!stationFound) return "Podana stacja nie istnieje.";
        if(!dateFound && parameterFound) return "Dla podanej daty nie ma dokładnych pomiarów. \n" +
                "Pomiary są zwykle przeprowadzane o pełnych godzinach i zwykle są od dnia poprzedniego do chwili obecnej. \n" +
                "Pomiary bliskie chwili obecnej mogą nie być jeszcze wykonane. Spróbuj wpisać wcześniejszy termin.";
        if(!parameterFound) return ("Podany parametr nie istnieje/nie jest badany na danej stacji pomiarowej.");
        return result;
    }

    /**
     * This function gets date from when measurements were taken and station from which measurements were taken.
     * It searches which parameter had the highest amplitude within given date until now on the given stations.
     * @param args - Arguments such as stations from which measurements were taken and date from when measurements were taken.
     * @param stations - Map of all stations
     * @return parameter which had the highest amplitude on the given stations at given time period.
     * @throws IOException - function throws such Exception when a problem with file has occurred. Also it is thrown when number of arguments is inappropriate
     * @throws ParseException - function throws such Exception when a problem with parsing date has occurred.
     */
    public static String fourthFunctionality(String[] args, LinkedHashMap<String, Station> stations) throws IOException, ParseException{
        if(args.length < 3) throw new IllegalArgumentException();
        FileReading helper = new FileReading("src/temporaryRequests/findAllRequest");
        String userJson = helper.readFromFile();
        Gson gson1 = new Gson();
        Gson gson2 = new Gson();
        Station[] userObject = gson1.fromJson(userJson, Station[].class);
        Double min = Double.MAX_VALUE;
        Double max = 0.0;
        Double diff = 0.0;
        String maxDiffParam = "";
        for (int i = 0; i < userObject.length; i++)
            stations.put(userObject[i].getStationName(), userObject[i]);
        for (String key : stations.keySet()) {
            for(int j = 1; j< args.length-1; j++) {
                if (args[j].toLowerCase().equals(key.toLowerCase())) {
                    String userJson1 = FileReading.readFromURL("http://api.gios.gov.pl/pjp-api/rest/station/sensors/" + stations.get(key).getId());
                    Positions[] sensors = gson2.fromJson(userJson1, Positions[].class);
                    Date beginDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).parse(args[args.length-1]);
                    for (int i = 0; i < sensors.length; i++) {
                        String userJson2 = FileReading.readFromURL("http://api.gios.gov.pl/pjp-api/rest/data/getData/" + sensors[i].getId());
                        Gson gson3 = new Gson();
                        SmogData smogParam = gson3.fromJson(userJson2, SmogData.class);
                        max = 0.0;
                        min = Double.MAX_VALUE;
                        for (SmogData.Values v : smogParam.getValues()) {
                            Date measDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).parse(v.getDate());
                            if (measDate.before(beginDate)) break;//todo zastanowic sie czy to na pewno dziala
                            if (v.getValue() > max) max = v.getValue();
                            if (v.getValue() < min && v.getValue() >= 0) min = v.getValue();
                            if (max - min > diff) {
                                diff = max - min;
                                maxDiffParam = smogParam.getKey();
                            }
                        }
                    }
                }
            }
        }
        if(maxDiffParam=="") return ("Brak pomiarów z podanej godziny.");
        else return ("Parametr, który uległ największym wahaniom: " + maxDiffParam + ". Uległ wahaniom równym: " + diff + " ug/m3");
    }

    /**
     * This function was created to search which parameter had the lowest value at the given time.
     * It takes date as input and returns which parameter had the lowest value at the given time.
     * It also returns what was its value;
     * @param args - Argument containing start date from which the lowest value will be searched
     * @param stations - Map of all stations
     * @return Parameter which had the lowest value at the given time.
     * @throws IOException - function throws such Exception when a problem with file has occurred. Also it is thrown when number of arguments is inappropriate
     * @throws ParseException - function throws such Exception when a problem with parsing date has occurred.
     */
    public static String fifthFunctionality(String[] args, LinkedHashMap<String, Station> stations) throws IOException, ParseException{
        if(args.length != 2) throw new IllegalArgumentException();
        FileReading helper = new FileReading("src/temporaryRequests/findAllRequest");
        String userJson = helper.readFromFile();
        Gson gson1 = new Gson();
        Gson gson2 = new Gson();
        Station[] userObject = gson1.fromJson(userJson, Station[].class);
        double min = Double.MAX_VALUE;
        Date givenDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).parse(args[1]);
        String minParam = "";
        for (int i = 0; i < userObject.length; i++) stations.put(userObject[i].getStationName(), userObject[i]);
        for (String key : stations.keySet()) {
            String userJson1 = FileReading.readFromURL("http://api.gios.gov.pl/pjp-api/rest/station/sensors/" + stations.get(key).getId());
            Positions[] sensors = gson2.fromJson(userJson1, Positions[].class);
            for (int i = 0; i < sensors.length; i++) {
                String userJson2 = FileReading.readFromURL("http://api.gios.gov.pl/pjp-api/rest/data/getData/" + sensors[i].getId());
/*//todo jak bede chciala robic lokalnie
                FileReading helper3 = new FileReading("src/temporaryRequests/DanePomiarowe/DataCacheForSensor" + sensors[i].getId());
                String userJson2 = helper3.readFromFile();*/
                Gson gson3 = new Gson();
                SmogData smogParam = gson3.fromJson(userJson2, SmogData.class);
                for(SmogData.Values v : smogParam.getValues()){
                    Date measDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).parse(v.getDate());
                    if(givenDate.equals(measDate)){
                        if(v.getValue() < min && v.getValue() >= 0) {
                            min = v.getValue();
                            minParam = smogParam.getKey();
                        }
                    }
                }
            }
        }
        if(minParam == "") return "Podana Data jest nieprawidłowa/Nie istnieją pomiary z podanego dnia i godziny";
        return ("Parametr, którego była najmniejsza wartość " + givenDate + " : " + minParam + ". Wynosiła: " + min + " ug/m3");
    }

    /**
     * This function searches for given station which parameters have exceeded their acceptable values.
     * It also sort this exceeded parameters in ascending order and returns such information to the user.
     * @param args - arguments provided by user, especially measurement stations and measurement date.
     * @param stations - map of all stations
     * @param acceptableValues - map of all parameters acceptable values
     * @return All parameters that have exceeded their acceptable values
     * @throws IOException- function throws such Exception when a problem with file has occurred. Also it is thrown when number of arguments is inappropriate
     * @throws ParseException- function throws such Exception when a problem with parsing date has occurred.
     */
    public static String sixthFunctionality(String[] args, LinkedHashMap<String, Station> stations, HashMap<String, Integer> acceptableValues) throws IOException, ParseException{
        if(args.length != 3) throw new IllegalArgumentException();
        FileReading helper = new FileReading("src/temporaryRequests/findAllRequest");
        String userJson = helper.readFromFile();
        Gson gson1 = new Gson();
        Gson gson2 = new Gson();
        String result = "";
        Station[] userObject = gson1.fromJson(userJson, Station[].class);
        Date givenDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).parse(args[2]);
        Map<String, Double> exceededParameters = new TreeMap<>();
        for (int i = 0; i < userObject.length; i++) stations.put(userObject[i].getStationName(), userObject[i]);
        for (String key : stations.keySet()) {
            if (args[1].toLowerCase().equals(key.toLowerCase())) {
                FileReading helper2 = new FileReading("src/temporaryRequests/Sensory/station" + stations.get(key).getId());
                String userJson1 = helper2.readFromFile();
                Positions[] sensors = gson2.fromJson(userJson1, Positions[].class);
                for (int i = 0; i < sensors.length; i++) {
                    String userJson2 = FileReading.readFromURL("http://api.gios.gov.pl/pjp-api/rest/data/getData/" + sensors[i].getId());
                    Gson gson3 = new Gson();
                    SmogData smogParam = gson3.fromJson(userJson2, SmogData.class);
                    for(SmogData.Values v : smogParam.getValues()){
                        Date measDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).parse(v.getDate());
                        if(givenDate.equals(measDate)){
                            if(v.getValue() > acceptableValues.get(smogParam.getKey())){
                                exceededParameters.put(smogParam.getKey(), v.getValue());
                            }
                        }
                    }
                }
            }
        }

        if(exceededParameters.keySet().isEmpty()) return ("Zaden parametr nie przekroczyl normy");
        //for(String s : exceededParameters.keySet()) exceededParameters.put(s,exceededParameters.get(s) - acceptableValues.get(s));
        exceededParameters = sortMap(exceededParameters);
        for(String s : exceededParameters.keySet()) result += "Parametr " + s + " przekroczył wartość o " + (exceededParameters.get(s)-acceptableValues.get(s)) + " ug/m3\n";
        return result;
    }

    /**
     * This function searches for given parameters when and where it had the lowest and the highest value and returns this information to the user.
     * @param args - arguments provided by user, especially measurement stations and measurement date.
     * @param stations - map of all stations
     * @return Stations and dates when given parameter had the lowest and the highest value
     * @throws IOException- function throws such Exception when a problem with file has occurred. Also it is thrown when number of arguments is inappropriate
     * @throws ParseException- function throws such Exception when a problem with parsing date has occurred.
     */
    public static String seventhFunctionality(String[] args, LinkedHashMap<String, Station> stations) throws IOException, ParseException{
        if(args.length != 2) throw new IllegalArgumentException();
        FileReading helper = new FileReading("src/temporaryRequests/findAllRequest");
        String userJson = helper.readFromFile();
        Gson gson1 = new Gson();
        Gson gson2 = new Gson();
        Double min_value = Double.MAX_VALUE;
        String min_station = "";
        Date min_date = null;
        Double max_value = 0.0;
        String max_station = "";
        Date max_date = null;
        Station[] userObject = gson1.fromJson(userJson, Station[].class);
        for (int i = 0; i < userObject.length; i++) stations.put(userObject[i].getStationName(), userObject[i]);
        for (String key : stations.keySet()) {
            FileReading helper2 = new FileReading("src/temporaryRequests/Sensory/station" + stations.get(key).getId());
            String userJson1 = helper2.readFromFile();
            Positions[] sensors = gson2.fromJson(userJson1, Positions[].class);
            for (int i = 0; i < sensors.length; i++) {
                String userJson2 = FileReading.readFromURL("http://api.gios.gov.pl/pjp-api/rest/data/getData/" + sensors[i].getId());
                Gson gson3 = new Gson();
                SmogData smogParam = gson3.fromJson(userJson2, SmogData.class);
                if(smogParam.getKey().equals(args[1].toUpperCase())) {
                    for (SmogData.Values v : smogParam.getValues()) {
                        Date measDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.UK).parse(v.getDate());
                        if (v.getValue() < min_value && v.getValue() >= 0) {
                            min_value = v.getValue();
                            min_station = key;
                            min_date = measDate;
                        }
                        if (v.getValue() > max_value && v.getValue() >= 0) {
                            max_value = v.getValue();
                            max_station = key;
                            max_date = measDate;
                        }
                    }
                }
            }
        }
        if(max_date != null && min_date != null) {
            String result = "Największą wartość parametr " + args[1].toUpperCase() + " miał na stacji: " + max_station +"\n Dnia: " + max_date + "\n Wynosiła ona: " + max_value + " ug/m3\n" ;
            result += ("Najmniejszą wartość parametr " + args[1].toUpperCase() + " miał na stacji: " + min_station +"\n Dnia: " + min_date + "\n Wynosiła ona: " + min_value + " ug/m3" );
            return result;
        }
        else return ("Błędna nazwa parametru!");
    }


    /**
     * This function searches given parameter value at the given time period.
     * Then it draws diagram presenting this parameter values at the given station in the given time period.
     * @param args - arguments provided by user, especially measurement stations and measurement start date and end date.
     * @param stations - map of all stations
     * @return Diagram presenting values for given parameter at given stations within given time period.
     * @throws IOException- function throws such Exception when a problem with file has occurred. Also it is thrown when number of arguments is inappropriate
     * @throws ParseException- function throws such Exception when a problem with parsing date has occurred.
     */
    public static String eighthFunctionality(String[] args, LinkedHashMap<String, Station> stations)throws IOException, ParseException{
        if(args.length < 5) throw new IllegalArgumentException();
        FileReading helper = new FileReading("src/temporaryRequests/findAllRequest");
        String userJson = helper.readFromFile();
        Gson gson1 = new Gson();
        Gson gson2 = new Gson();
        float converter = averageValue(args, stations, 1, 2);
        boolean foundParam = false;
        String result = "";
        int dateIndex = args.length - 1;
        Station[] userObject = gson1.fromJson(userJson, Station[].class);
        Date endDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).parse(args[dateIndex]);
        Date beginDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).parse(args[dateIndex-1]);
        for (int i = 0; i < userObject.length; i++) stations.put(userObject[i].getStationName(), userObject[i]);
        for (String key : stations.keySet()) {
            for (int j = 2; j < args.length - 1; j++) {
                if (args[j].toLowerCase().equals(key.toLowerCase())) {
                    FileReading helper2 = new FileReading("src/temporaryRequests/Sensory/station" + stations.get(key).getId());
                    String userJson1 = helper2.readFromFile();
                    Positions[] sensors = gson2.fromJson(userJson1, Positions[].class);
                    for (int i = 0; i < sensors.length; i++) {
                        String userJson2 = FileReading.readFromURL("http://api.gios.gov.pl/pjp-api/rest/data/getData/" + sensors[i].getId());
                        Gson gson3 = new Gson();
                        SmogData smogParam = gson3.fromJson(userJson2, SmogData.class);
                        if (smogParam.getKey().equals(args[1].toUpperCase())) {
                            for (SmogData.Values v : smogParam.getValues()) {
                                Date measDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).parse(v.getDate());
                                if (!measDate.before(beginDate) && !measDate.after(endDate) && v.getValue() >= 0) {
                                    result += measDate + " (" + key + ") ";
                                    result += drawDiagram(converter, v.getValue()) + v.getValue() + " ug/m3 \n";
                                    foundParam = true;
                                }
                            }
                        }
                    }
                }
            }
        }
        if(!foundParam) return ("Nie znaleziono parametru. Parametr jest błędny lub podana stacja nie prowadzi pomiarów podanego parametru.");
    return result;
    }
}
