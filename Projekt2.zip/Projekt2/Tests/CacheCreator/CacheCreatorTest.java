package CacheCreator;

import org.junit.Test;

import static org.junit.Assert.*;

public class CacheCreatorTest {

    @Test
    public void checkCacheExpiration() {
        String outDate = "2019-01-20 15:00:00";
        String inDate = "2019-01-21 08:00:00";
        assertTrue(CacheCreator.checkCacheExpiration(outDate));
        assertFalse(CacheCreator.checkCacheExpiration(inDate));
    }
}