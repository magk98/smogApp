package UtilAlgos;

import org.junit.Test;

import java.io.IOException;
import java.text.ParseException;

import static org.junit.Assert.*;

public class SingletonTest {

    @Test
    public void commander() {
        String[] args = new String[0];
        try {
            assertEquals(Singleton.getSingleEntry().commander(args), "\nThis is Smog App which allows you to follow current air condition in your area.\n" +
                    "You can use this program in a few possible ways depending on which arguments will you provide:\n" +
                    "1. \"-r\" Which refreshes all caches.\n" +
                    "2. \"-c\" Which checks and refreshes all caches when it's needed.\n" +
                    "3. \"-1 <Station name>\" Which shows you current air condition from given station.\n" +
                    "4. \"-2 <Station name> <Parameter name> <Date>\" Which shows you value of given parameter in given time from given station. \n" +
                    "5. \"-3 <Station name> <Parameter name> <Period Start> <Period End>\" Which shows you average value of a given parameter between given dates from given station.\n" +
                    "6. \"-4 <Station name> <Period start>\" Which shows you which parameter had most difference between max and min values from given start date until now.\n" +
                    "7. \"-5 <Date>\" Which shows you which parameter had the lowest value at given time.\n" +
                    "8. \"-6 <Station name> <Date> \" Which shows you which parameters have exceeded their acceptable values.\n" +
                    "9. \"-7 <Parameter name>\" Which shows you when and where given parameter had the lowest and the highest value. \n" +
                    "10. \"-8 <Parameter name> <Station/s> <Period start> <Period End> \" Which displays values of the given parameter and how they changed in the given time period on the given stations as a diagram.\n" +
                    "Be careful: \n" +
                    "Parameter name should be one from the \"NO2, SO2, PM10, PM25, C6H6, O3, CO\". \n" +
                    "Date should be in format \"YYYY-MM-DD HH:MM:SS\" and usually measurements are taken at full hours.\n\n");
            String[] testArray = new String[1];
            testArray[0] = "-r";
            assertEquals(Singleton.getSingleEntry().commander(testArray), "Cache is up to date, no need to refresh.");
            }catch(IOException e){
            fail();
        } catch (ParseException p){
            fail();
        }
    }

    @Test
    public void getSingleEntry() {
    }
}